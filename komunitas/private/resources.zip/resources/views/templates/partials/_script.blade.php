<script src="{{ asset('public/assets/js/jquery.min.js')}}"></script>
<script src="{{ asset('public/assets/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('public/assets/js/metisMenu.min.js')}}"></script>
<script src="{{ asset('public/assets/js/jquery.slimscroll.js')}}"></script>
<script src="{{ asset('public/assets/js/waves.min.js')}}"></script>
<!-- Required datatable js -->
<script src="{{ asset('public/assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<!-- Buttons examples -->
<script src="{{ asset('public/assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/jszip.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/pdfmake.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/vfs_fonts.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/buttons.html5.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/buttons.print.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/buttons.colVis.min.js')}}"></script>
<!-- Responsive examples -->
<script src="{{ asset('public/assets/plugins/datatables/dataTables.responsive.min.js')}}"></script>
<script src="{{ asset('public/assets/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>
<!-- Datatable init js -->
<script src="{{ asset('public/assets/pages/datatables.init.js')}}"></script>
<!-- App js -->
<script src="{{ asset('public/assets/js/app.js')}}"></script>
<script src="assets/js/app.js"></script>
<!-- Jquery-Ui -->
<script src="{{ asset('public/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
<script src="{{ asset('public/plugins/moment/moment.js')}}"></script>
<script src="{{ asset('public/plugins/fullcalendar/js/fullcalendar.min.js')}}"></script>
<script src="{{ asset('public/assets/pages/calendar-init.js')}}"></script>