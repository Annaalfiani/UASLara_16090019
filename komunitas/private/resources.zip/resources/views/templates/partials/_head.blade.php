<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
<title>UKM Rana 9 - Poltek Tegal</title>
<meta content="Admin Dashboard" name="description">
<meta content="Themesbrand" name="author">
<link rel="shortcut icon" href="public/assets/images/favicon.ico">
<!-- DataTables -->
<link href="{{ asset('public/assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<!--calendar css-->
<link href="{{ asset('public/assets/plugins/fullcalendar/css/fullcalendar.min.css')}}" rel="stylesheet">
<link href="{{ asset('public/assets/css/bootstrap.min.css" rel="stylesheet')}}" type="text/css">
<link href="{{ asset('public/assets/css/metismenu.min.css" rel="stylesheet')}}" type="text/css">
<!-- Responsive datatable examples -->
<link href="{{ asset('public/assets/plugins/datatables/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/assets/css/metismenu.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/assets/css/icons.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/assets/css/style.css')}}" rel="stylesheet" type="text/css">
</head>