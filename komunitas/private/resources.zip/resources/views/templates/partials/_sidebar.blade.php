<div class="left side-menu">
		<div class="slimscroll-menu" id="remove-scroll">
			<!--- Sidemenu -->
			<div id="sidebar-menu">
				<!-- Left Menu Start -->
				<ul class="metismenu" id="side-menu">
					<li class="menu-title">Main</li>
					<li>
						<a href="index.html" class="waves-effect"><i class="ti-home"></i><span class="badge badge-primary badge-pill float-right">2</span><span>Dashboard</span></a>
					</li>
					<li>
						<a href="{{route('anggota')}}" class="waves-effect"><i class="typcn typcn-group"></i><span>Anggota</span></a>
					</li>
					<li>
						<a href="{{route('galeri')}}" class="waves-effect"><i class="typcn typcn-image"></i><span>Galeri</span></a>
					</li>
					<li>
						<a href="calendar.html" class="waves-effect"><i class="mdi mdi-calendar-check-outline"></i><span>Jadwal Kegiatan</span></a>
					</li>
						<li>
						<a href=".." class="waves-effect"><i class="mdi mdi-trophy-variant"></i><span>Prestasi</span></a>
					</li>
					</li>
					<li>
						<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-ticket-confirmation"></i><span>Event Photography <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span></span></a>
						<ul class="submenu">
							<li>
								<a href="{{route('eventnow')}}">Bulan Ini</a>
							</li>
							<li>
								<a href="ui-alerts.html">Coming Soon</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);" class="waves-effect"><i class="ti-email"></i><span> Document <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span></span></a>
						<ul class="submenu">
							<li>
								<a href="charts-morris.html">LPJ</a>
							</li>
							<li>
								<a href="charts-chartist.html">Proposal Inventaris</a>
							</li>
							<li>
								<a href="charts-chartist.html">Proposal Kegiatan</a>
							</li>
						</ul>
					</li>
						</ul>
					</li>
				</ul>
			</div>
			<!-- Sidebar -->
			<div class="clearfix"></div>
		</div>
		<!-- Sidebar -left --></div>