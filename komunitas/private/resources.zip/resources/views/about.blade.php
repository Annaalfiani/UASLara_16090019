@extends('templates.default')

@section('content')
<div class="content">
<p>Keluarga cemara</p>
</div>

@endsection